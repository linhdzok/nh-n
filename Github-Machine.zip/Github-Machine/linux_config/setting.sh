sudo apt-get update
sudo apt-get install xfce4 xfce4-terminal
wget https://dl.google.com/linux/direct/chrome-remote-desktop_current_amd64.deb
sudo dpkg -i chrome*
sudo apt-get install -f
